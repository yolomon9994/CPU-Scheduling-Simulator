#include "sjf.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>

void sjf_scheduler(Process processes[], int n, SchedulingResult *result) {
    int completed = 0;
    int current_time = 0;
    
    for (int i = 0; i < n; i++) {
        processes[i].remaining_time = processes[i].burst_time;
        processes[i].start_time = -1;
        processes[i].finish_time = -1;
    }
    
    while (completed < n) {
        int shortest_job_index = -1;
        int min_burst_time = INT_MAX;
        bool cpu_idle_this_cycle = true;
        
        for (int i = 0; i < n; i++) {
            if (processes[i].arrival_time <= current_time && processes[i].remaining_time > 0) {
                cpu_idle_this_cycle = false;
                if (processes[i].remaining_time < min_burst_time) {
                    min_burst_time = processes[i].remaining_time;
                    shortest_job_index = i;
                }
            }
        }
        
        if (cpu_idle_this_cycle) {
            current_time++;
            continue;
        }
        
        if (processes[shortest_job_index].start_time == -1) {
            processes[shortest_job_index].start_time = current_time;
        }
        
        current_time += processes[shortest_job_index].remaining_time;
        processes[shortest_job_index].finish_time = current_time;
        processes[shortest_job_index].remaining_time = 0;
        completed++;
    }
    
    calculate_metrics(processes, n, result);
}
