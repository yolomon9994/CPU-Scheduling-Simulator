#ifndef METRICS_H
#define METRICS_H

#include "process.h"

void calculate_metrics(Process processes[], int n, SchedulingResult *result);

#endif
