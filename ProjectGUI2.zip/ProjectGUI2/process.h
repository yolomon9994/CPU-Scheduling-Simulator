#ifndef PROCESS_H
#define PROCESS_H

#include <stdbool.h>

#define MAX_PROCESSES 10

typedef struct {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int start_time;
    int finish_time;
} Process;

typedef struct {
    Process processes[MAX_PROCESSES];
    int count;
    float avg_waiting_time;
    float avg_turnaround_time;
    float cpu_utilization;
    char algorithm[20];
} SchedulingResult;

#endif
