#include "simulation.h"
#include <string.h> // For memcpy
#include <stdio.h>  // For strcpy


void run_all_algorithms(Process processes[], int count, int quantum, SchedulingResult results[3]) {
   
    Process fcfs_processes[MAX_PROCESSES];
    Process sjf_processes[MAX_PROCESSES];
    Process rr_processes[MAX_PROCESSES];
    
    memcpy(fcfs_processes, processes, sizeof(Process) * count);
    memcpy(sjf_processes, processes, sizeof(Process) * count);
    memcpy(rr_processes, processes, sizeof(Process) * count);
    
    // Run FCFS
    strcpy(results[0].algorithm, "FCFS");
    results[0].count = count;
    fcfs_scheduler(fcfs_processes, count, &results[0]);
    
    // Run SJF
    strcpy(results[1].algorithm, "SJF");
    results[1].count = count;
    sjf_scheduler(sjf_processes, count, &results[1]);
    
    // Run Round Robin
    strcpy(results[2].algorithm, "Round Robin");
    results[2].count = count;
    rr_scheduler(rr_processes, count, quantum, &results[2]);
}

void run_two_algorithms(Process processes[], int count, int quantum, 
                        const char* algo1_name, const char* algo2_name, 
                        SchedulingResult results[2]) {
    
    Process algo1_processes[MAX_PROCESSES];
    memcpy(algo1_processes, processes, sizeof(Process) * count);

    Process algo2_processes[MAX_PROCESSES];
    memcpy(algo2_processes, processes, sizeof(Process) * count);

    strcpy(results[0].algorithm, algo1_name);
    results[0].count = count;
    if (strcmp(algo1_name, "FCFS") == 0) {
        fcfs_scheduler(algo1_processes, count, &results[0]);
    } else if (strcmp(algo1_name, "SJF") == 0) {
        sjf_scheduler(algo1_processes, count, &results[0]);
    } else if (strcmp(algo1_name, "Round Robin") == 0) {
        rr_scheduler(algo1_processes, count, quantum, &results[0]);
    }

    strcpy(results[1].algorithm, algo2_name);
    results[1].count = count;
    if (strcmp(algo2_name, "FCFS") == 0) {
        fcfs_scheduler(algo2_processes, count, &results[1]);
    } else if (strcmp(algo2_name, "SJF") == 0) {
        sjf_scheduler(algo2_processes, count, &results[1]);
    } else if (strcmp(algo2_name, "Round Robin") == 0) {
        rr_scheduler(algo2_processes, count, quantum, &results[1]);
    }
}
