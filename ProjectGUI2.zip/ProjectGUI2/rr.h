#ifndef RR_H
#define RR_H

#include "process.h"
#include "metrics.h"

void rr_scheduler(Process processes[], int n, int quantum, SchedulingResult *result);

#endif
