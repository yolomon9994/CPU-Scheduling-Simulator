#ifndef SJF_H
#define SJF_H

#include "process.h"
#include "metrics.h"

void sjf_scheduler(Process processes[], int n, SchedulingResult *result);

#endif
