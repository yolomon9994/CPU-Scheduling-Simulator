#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "process.h"
#include "fcfs.h"
#include "sjf.h"
#include "rr.h"
#include "simulation.h"


GtkWidget *algorithm_combo;
GtkWidget *quantum_entry;
GtkWidget *results_text;
GtkWidget *quantum_label;

GtkWidget *at_entry;
GtkWidget *bt_entry;
GtkWidget *process_list_display;
GtkTextBuffer *process_list_buffer;

GtkWidget *algo1_compare_combo;
GtkWidget *algo2_compare_combo;
GtkWidget *compare_two_button;
GtkWidget *algo1_compare_label;
GtkWidget *algo2_compare_label;

GList *added_processes = NULL;
int next_pid = 1; // Auto-incrementing PID


static void on_add_process_clicked(GtkWidget *widget, gpointer data) {
    const gchar *at_text = gtk_entry_get_text(GTK_ENTRY(at_entry));
    const gchar *bt_text = gtk_entry_get_text(GTK_ENTRY(bt_entry));

    if (strlen(at_text) == 0 || strlen(bt_text) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_CLOSE,
            "Please enter both Arrival Time and Burst Time.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    int at = atoi(at_text);
    int bt = atoi(bt_text);

    if (bt <= 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_CLOSE,
            "Invalid Burst Time: Must be a positive integer.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
    if (at < 0) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_CLOSE,
            "Invalid Arrival Time: Cannot be negative.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    if (g_list_length(added_processes) >= MAX_PROCESSES) {
        GtkWidget *dialog = gtk_message_dialog_new(
            GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_CLOSE,
            "Maximum number of processes (%d) reached. Cannot add more.", MAX_PROCESSES);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    Process *new_process = g_malloc(sizeof(Process));
    new_process->pid = next_pid++;
    new_process->arrival_time = at;
    new_process->burst_time = bt;
    new_process->remaining_time = bt;
    new_process->start_time = -1;
    new_process->finish_time = -1;

    added_processes = g_list_append(added_processes, new_process);

    GtkTextIter end_iter;
    gtk_text_buffer_get_end_iter(process_list_buffer, &end_iter);
    char process_str[100];
    snprintf(process_str, sizeof(process_str), "PID: %d, AT: %d, BT: %d\n",
             new_process->pid, new_process->arrival_time, new_process->burst_time);
    gtk_text_buffer_insert(process_list_buffer, &end_iter, process_str, -1);

    gtk_entry_set_text(GTK_ENTRY(at_entry), "");
    gtk_entry_set_text(GTK_ENTRY(bt_entry), "");
    gtk_widget_grab_focus(at_entry);
}

static void on_clear_processes_clicked(GtkWidget *widget, gpointer data) {
    g_list_foreach(added_processes, (GFunc)g_free, NULL);
    g_list_free(added_processes);
    added_processes = NULL;

    next_pid = 1;

    gtk_text_buffer_set_text(process_list_buffer, "", -1);
    gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), "", -1);
}


static void update_quantum_entry_sensitivity() {
    gboolean quantum_needed = FALSE;

    // Check main algorithm combo
    const gchar *main_algo_selection = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algorithm_combo));
    if (main_algo_selection && (strcmp(main_algo_selection, "Round Robin") == 0 || strcmp(main_algo_selection, "Compare All") == 0)) {
        quantum_needed = TRUE;
    }

    // Check compare algorithm 1 combo
    const gchar *algo1_comp_selection = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algo1_compare_combo));
    if (algo1_comp_selection && strcmp(algo1_comp_selection, "Round Robin") == 0) {
        quantum_needed = TRUE;
    }

    // Check compare algorithm 2 combo
    const gchar *algo2_comp_selection = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algo2_compare_combo));
    if (algo2_comp_selection && strcmp(algo2_comp_selection, "Round Robin") == 0) {
        quantum_needed = TRUE;
    }

    gtk_widget_set_sensitive(quantum_label, quantum_needed);
    gtk_widget_set_sensitive(quantum_entry, quantum_needed);
}



static void on_algorithm_changed(GtkComboBox *widget, gpointer data) {
    update_quantum_entry_sensitivity();
}

// compare algorithm combo boxes
static void on_algo1_compare_changed(GtkComboBox *widget, gpointer data) {
    update_quantum_entry_sensitivity();
}

static void on_algo2_compare_changed(GtkComboBox *widget, gpointer data) {
    update_quantum_entry_sensitivity();
}



static void on_compare_two_clicked(GtkWidget *widget, gpointer data) {
    const gchar *algo1_name = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algo1_compare_combo));
    const gchar *algo2_name = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algo2_compare_combo));
    const gchar *quantum_text = gtk_entry_get_text(GTK_ENTRY(quantum_entry));
    int quantum = quantum_text ? atoi(quantum_text) : 2;

    int process_count = g_list_length(added_processes);

    if (process_count == 0) {
        gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                                 "Error: No processes have been added for simulation. Please use 'Add Process'.", -1);
        return;
    }

    if (strcmp(algo1_name, algo2_name) == 0) {
        gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                                 "Error: Please select two different algorithms for comparison.", -1);
        return;
    }

    if ((strcmp(algo1_name, "Round Robin") == 0 || strcmp(algo2_name, "Round Robin") == 0) && quantum <= 0) {
         gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                         "Error: Time Quantum must be a positive integer when comparing with Round Robin.", -1);
         return;
    }

    Process processes_for_simulation[MAX_PROCESSES];
    GList *l;
    int i = 0;
    for (l = added_processes; l != NULL && i < MAX_PROCESSES; l = l->next) {
        memcpy(&processes_for_simulation[i], l->data, sizeof(Process));
        i++;
    }

    SchedulingResult comparison_results[2]; // Array to hold results of 2 algorithms
    
    run_two_algorithms(processes_for_simulation, process_count, quantum, algo1_name, algo2_name, comparison_results);

    char results_str[2048] = {0};
    snprintf(results_str, sizeof(results_str),
        "Comparison between %s and %s:\n\n"
        "Process Count: %d\n"
        "Time Quantum (for RR): %d\n\n",
        algo1_name, algo2_name, process_count, quantum);
    
    int best_waiting = 0, best_turnaround = 0, best_utilization = 0;

    if (comparison_results[1].avg_waiting_time < comparison_results[best_waiting].avg_waiting_time) {
        best_waiting = 1;
    }
    if (comparison_results[1].avg_turnaround_time < comparison_results[best_turnaround].avg_turnaround_time) {
        best_turnaround = 1;
    }
    if (comparison_results[1].cpu_utilization > comparison_results[best_utilization].cpu_utilization) {
        best_utilization = 1;
    }
    
    for (int j = 0; j < 2; j++) {
        char temp[512];
        snprintf(temp, sizeof(temp),
            "%s:\n"
            "  Avg Waiting Time: %.2f%s\n"
            "  Avg Turnaround Time: %.2f%s\n"
            "  CPU Utilization: %.2f%%%s\n\n",
            comparison_results[j].algorithm,
            comparison_results[j].avg_waiting_time,
            (j == best_waiting) ? " (BEST)" : "",
            comparison_results[j].avg_turnaround_time,
            (j == best_turnaround) ? " (BEST)" : "",
            comparison_results[j].cpu_utilization,
            (j == best_utilization) ? " (BEST)" : "");
        strncat(results_str, temp, sizeof(results_str) - strlen(results_str) - 1);
    }
    
    strncat(results_str, "\nSummary:\n", sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, comparison_results[best_waiting].algorithm, sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, " has the best average waiting time.\n", sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, comparison_results[best_turnaround].algorithm, sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, " has the best average turnaround time.\n", sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, comparison_results[best_utilization].algorithm, sizeof(results_str) - strlen(results_str) - 1);
    strncat(results_str, " has the best CPU utilization.\n", sizeof(results_str) - strlen(results_str) - 1);

    gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                             results_str, -1);
}

static void on_simulate_clicked(GtkWidget *widget, gpointer data) {
    const gchar *algorithm = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(algorithm_combo));
    const gchar *quantum_text = gtk_entry_get_text(GTK_ENTRY(quantum_entry));
    int quantum = quantum_text ? atoi(quantum_text) : 2;

    int process_count = g_list_length(added_processes);
    
    if (process_count == 0) {
        gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                                 "Error: No processes have been added for simulation. Please use 'Add Process'.", -1);
        return;
    }
    
    Process processes_for_simulation[MAX_PROCESSES];
    GList *l;
    int i = 0;
    for (l = added_processes; l != NULL && i < MAX_PROCESSES; l = l->next) {
        memcpy(&processes_for_simulation[i], l->data, sizeof(Process));
        i++;
    }

    char results_str[2048] = {0};

    if (strcmp(algorithm, "Compare All") == 0) {
        if (quantum <= 0) {
             gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                             "Error: Time Quantum must be a positive integer when comparing all algorithms (for Round Robin).", -1);
             return;
        }

        SchedulingResult results[3];
        run_all_algorithms(processes_for_simulation, process_count, quantum, results);
        
        snprintf(results_str, sizeof(results_str),
            "Comparison of All Algorithms:\n\n"
            "Process Count: %d\n"
            "Time Quantum (for RR): %d\n\n",
            process_count, quantum);
        
        int best_waiting = 0, best_turnaround = 0, best_utilization = 0;
        for (int j = 1; j < 3; j++) {
            if (results[j].avg_waiting_time < results[best_waiting].avg_waiting_time) {
                best_waiting = j;
            }
            if (results[j].avg_turnaround_time < results[best_turnaround].avg_turnaround_time) {
                best_turnaround = j;
            }
            if (results[j].cpu_utilization > results[best_utilization].cpu_utilization) {
                best_utilization = j;
            }
        }
        
        for (int j = 0; j < 3; j++) {
            char temp[512];
            snprintf(temp, sizeof(temp),
                "%s:\n"
                "  Avg Waiting Time: %.2f%s\n"
                "  Avg Turnaround Time: %.2f%s\n"
                "  CPU Utilization: %.2f%%%s\n\n",
                results[j].algorithm,
                results[j].avg_waiting_time,
                (j == best_waiting) ? " (BEST)" : "",
                results[j].avg_turnaround_time,
                (j == best_turnaround) ? " (BEST)" : "",
                results[j].cpu_utilization,
                (j == best_utilization) ? " (BEST)" : "");
            strncat(results_str, temp, sizeof(results_str) - strlen(results_str) - 1);
        }
        
        strncat(results_str, "\nSummary:\n", sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, results[best_waiting].algorithm, sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, " has the best average waiting time.\n", sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, results[best_turnaround].algorithm, sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, " has the best average turnaround time.\n", sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, results[best_utilization].algorithm, sizeof(results_str) - strlen(results_str) - 1);
        strncat(results_str, " has the best CPU utilization.\n", sizeof(results_str) - strlen(results_str) - 1);
    } else {
        SchedulingResult result;
        result.count = process_count;
        
        Process current_algo_processes[MAX_PROCESSES];
        memcpy(current_algo_processes, processes_for_simulation, sizeof(Process) * process_count);

        if (strcmp(algorithm, "FCFS") == 0) {
            fcfs_scheduler(current_algo_processes, process_count, &result);
        } else if (strcmp(algorithm, "SJF") == 0) {
            sjf_scheduler(current_algo_processes, process_count, &result);
        } else if (strcmp(algorithm, "Round Robin") == 0) {
            if (quantum <= 0) {
                 gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                                 "Error: Time Quantum must be a positive integer for Round Robin.", -1);
                 return;
            }
            rr_scheduler(current_algo_processes, process_count, quantum, &result);
        }
        
        snprintf(results_str, sizeof(results_str),
            "Algorithm: %s\n"
            "Process Count: %d\n"
            "Average Waiting Time: %.2f\n"
            "Average Turnaround Time: %.2f\n"
            "CPU Utilization: %.2f%%\n\n"
            "Process Details:\n"
            "PID\tArrival\tBurst\tStart\tFinish\tWaiting\tTurnaround\n",
            algorithm, process_count, 
            result.avg_waiting_time, 
            result.avg_turnaround_time, 
            result.cpu_utilization);
        
        for (int j = 0; j < process_count; j++) {
            char line[100];
            int waiting = current_algo_processes[j].start_time - current_algo_processes[j].arrival_time;
            if (waiting < 0) waiting = 0;
            int turnaround = current_algo_processes[j].finish_time - current_algo_processes[j].arrival_time;

            snprintf(line, sizeof(line), "%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
                     current_algo_processes[j].pid,
                     current_algo_processes[j].arrival_time,
                     current_algo_processes[j].burst_time,
                     current_algo_processes[j].start_time,
                     current_algo_processes[j].finish_time,
                     waiting,
                     turnaround);
            strncat(results_str, line, sizeof(results_str) - strlen(results_str) - 1);
        }
    }
    
    gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(results_text)), 
                             results_str, -1);
}

static void on_save_clicked(GtkWidget *widget, gpointer data) {
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
    GtkTextIter start, end;
    gtk_text_buffer_get_start_iter(buffer, &start);
    gtk_text_buffer_get_end_iter(buffer, &end);
    gchar *text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);

    GtkWidget *dialog;
    GtkFileChooserAction action = GTK_FILE_CHOOSER_ACTION_SAVE;
    gint res;

    dialog = gtk_file_chooser_dialog_new("Save Simulation Results",
                                         GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
                                         action,
                                         "_Cancel", GTK_RESPONSE_CANCEL,
                                         "_Save", GTK_RESPONSE_ACCEPT,
                                         NULL);

    gtk_file_chooser_set_do_overwrite_confirmation(GTK_FILE_CHOOSER(dialog), TRUE);
    gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dialog), "simulation_results.txt");

    res = gtk_dialog_run(GTK_DIALOG(dialog));
    if (res == GTK_RESPONSE_ACCEPT) {
        char *filename;
        filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
        
        FILE *file = fopen(filename, "w");
        if (file) {
            fprintf(file, "%s", text);
            fclose(file);
        } else {
            GtkWidget *message_dialog = gtk_message_dialog_new(
                GTK_WINDOW(gtk_widget_get_ancestor(widget, GTK_TYPE_WINDOW)),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_ERROR,
                GTK_BUTTONS_CLOSE,
                "Error: Could not save file to %s.\nPlease check file permissions or location.", filename);
            gtk_dialog_run(GTK_DIALOG(message_dialog));
            gtk_widget_destroy(message_dialog);
        }
        g_free(filename);
    }

    gtk_widget_destroy(dialog);
    g_free(text);
}


int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *simulate_button;
    GtkWidget *save_button;
    GtkWidget *algorithm_label;
    GtkWidget *at_label;
    GtkWidget *bt_label;
    GtkWidget *add_process_button;
    GtkWidget *clear_processes_button;
    GtkWidget *scrolled_window_results;
    GtkWidget *process_list_scrolled_window;
    
    gtk_init(&argc, &argv);
    
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "CPU Scheduling Simulator");
    gtk_window_set_default_size(GTK_WINDOW(window), 750, 700); // Increased size slightly
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    grid = gtk_grid_new();
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10);
    gtk_grid_set_row_spacing(GTK_GRID(grid), 10);
    gtk_container_add(GTK_CONTAINER(window), grid);
    
    // Main Algorithm Selection
    algorithm_label = gtk_label_new("Select Algorithm:");
    gtk_label_set_xalign(GTK_LABEL(algorithm_label), 0);
    gtk_grid_attach(GTK_GRID(grid), algorithm_label, 0, 0, 1, 1);
    
    algorithm_combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_combo), "FCFS");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_combo), "SJF");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_combo), "Round Robin");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algorithm_combo), "Compare All");
    gtk_combo_box_set_active(GTK_COMBO_BOX(algorithm_combo), 0);
    g_signal_connect(algorithm_combo, "changed", G_CALLBACK(on_algorithm_changed), NULL);
    gtk_grid_attach(GTK_GRID(grid), algorithm_combo, 1, 0, 3, 1);

    // Time Quantum Input
    quantum_label = gtk_label_new("Time Quantum (for RR):");
    gtk_label_set_xalign(GTK_LABEL(quantum_label), 0);
    gtk_grid_attach(GTK_GRID(grid), quantum_label, 0, 1, 1, 1);
    
    quantum_entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(quantum_entry), "2");
    gtk_entry_set_width_chars(GTK_ENTRY(quantum_entry), 5);
    gtk_grid_attach(GTK_GRID(grid), quantum_entry, 1, 1, 3, 1);


    // Process Input (AT, BT)
    at_label = gtk_label_new("Arrival Time (AT):");
    gtk_label_set_xalign(GTK_LABEL(at_label), 0);
    gtk_grid_attach(GTK_GRID(grid), at_label, 0, 2, 1, 1);
    at_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(at_entry), "e.g., 0");
    gtk_grid_attach(GTK_GRID(grid), at_entry, 1, 2, 1, 1);

    bt_label = gtk_label_new("Burst Time (BT):");
    gtk_label_set_xalign(GTK_LABEL(bt_label), 0);
    gtk_grid_attach(GTK_GRID(grid), bt_label, 2, 2, 1, 1);
    bt_entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(bt_entry), "e.g., 10");
    gtk_grid_attach(GTK_GRID(grid), bt_entry, 3, 2, 1, 1);

    // Add Process and Clear Processes Buttons
    add_process_button = gtk_button_new_with_label("Add Process");
    g_signal_connect(add_process_button, "clicked", G_CALLBACK(on_add_process_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), add_process_button, 0, 3, 2, 1);

    clear_processes_button = gtk_button_new_with_label("Clear All Processes");
    g_signal_connect(clear_processes_button, "clicked", G_CALLBACK(on_clear_processes_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), clear_processes_button, 2, 3, 2, 1);

    // Display of Added Processes
    process_list_scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(process_list_scrolled_window),
                                   GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_grid_attach(GTK_GRID(grid), process_list_scrolled_window, 0, 4, 4, 1);
    gtk_widget_set_vexpand(process_list_scrolled_window, FALSE);
    gtk_widget_set_size_request(process_list_scrolled_window, -1, 100);

    process_list_display = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(process_list_display), FALSE);
    gtk_text_view_set_monospace(GTK_TEXT_VIEW(process_list_display), TRUE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(process_list_display), GTK_WRAP_WORD);
    process_list_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(process_list_display));
    gtk_container_add(GTK_CONTAINER(process_list_scrolled_window), process_list_display);

    // Simulate Button (for single algorithm or Compare All)
    simulate_button = gtk_button_new_with_label("Simulate CPU Scheduling");
    g_signal_connect(simulate_button, "clicked", G_CALLBACK(on_simulate_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), simulate_button, 0, 5, 4, 1);


    // Separator between the process adding and the two compare
    gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), 0, 6, 4, 1);
    
    // Labels and dropdowns for comparing two algorithms
    algo1_compare_label = gtk_label_new("Compare Algorithm 1:");
    gtk_label_set_xalign(GTK_LABEL(algo1_compare_label), 0);
    gtk_grid_attach(GTK_GRID(grid), algo1_compare_label, 0, 7, 1, 1);

    algo1_compare_combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo1_compare_combo), "FCFS");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo1_compare_combo), "SJF");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo1_compare_combo), "Round Robin");
    gtk_combo_box_set_active(GTK_COMBO_BOX(algo1_compare_combo), 0);
    // Connect signal for algo1_compare_combo ---
    g_signal_connect(algo1_compare_combo, "changed", G_CALLBACK(on_algo1_compare_changed), NULL);

    gtk_grid_attach(GTK_GRID(grid), algo1_compare_combo, 1, 7, 3, 1);

    algo2_compare_label = gtk_label_new("Compare Algorithm 2:");
    gtk_label_set_xalign(GTK_LABEL(algo2_compare_label), 0);
    gtk_grid_attach(GTK_GRID(grid), algo2_compare_label, 0, 8, 1, 1);

    algo2_compare_combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo2_compare_combo), "FCFS");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo2_compare_combo), "SJF");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(algo2_compare_combo), "Round Robin");
    gtk_combo_box_set_active(GTK_COMBO_BOX(algo2_compare_combo), 1); // Default to SJF for second
    // Connect signal for algo2_compare_combo ---
    g_signal_connect(algo2_compare_combo, "changed", G_CALLBACK(on_algo2_compare_changed), NULL);

    gtk_grid_attach(GTK_GRID(grid), algo2_compare_combo, 1, 8, 3, 1);

    // Button for comparing two selected algorithms
    compare_two_button = gtk_button_new_with_label("Compare Selected Algorithms");
    g_signal_connect(compare_two_button, "clicked", G_CALLBACK(on_compare_two_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), compare_two_button, 0, 9, 4, 1);


    // Simulation Results Display
    scrolled_window_results = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window_results),
                                   GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_grid_attach(GTK_GRID(grid), scrolled_window_results, 0, 10, 4, 1);
    gtk_widget_set_hexpand(scrolled_window_results, TRUE);
    gtk_widget_set_vexpand(scrolled_window_results, TRUE);
    
    results_text = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(results_text), FALSE);
    gtk_text_view_set_monospace(GTK_TEXT_VIEW(results_text), TRUE);
    gtk_container_add(GTK_CONTAINER(scrolled_window_results), results_text);

    // Save Results Button
    save_button = gtk_button_new_with_label("Save Results to File");
    g_signal_connect(save_button, "clicked", G_CALLBACK(on_save_clicked), results_text);
    gtk_grid_attach(GTK_GRID(grid), save_button, 0, 11, 4, 1);
    
    gtk_widget_show_all(window);
    
    update_quantum_entry_sensitivity();


    gtk_main();
    
    g_list_foreach(added_processes, (GFunc)g_free, NULL);
    g_list_free(added_processes);

    return 0;
}
