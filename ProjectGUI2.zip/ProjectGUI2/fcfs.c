#include "fcfs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fcfs_scheduler(Process processes[], int n, SchedulingResult *result) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (processes[j].arrival_time > processes[j+1].arrival_time) {
                Process temp = processes[j];
                processes[j] = processes[j+1];
                processes[j+1] = temp;
            }
        }
    }

    int current_time = 0;
    for (int i = 0; i < n; i++) {
        if (current_time < processes[i].arrival_time) {
            current_time = processes[i].arrival_time;
        }
        processes[i].start_time = current_time;
        processes[i].finish_time = current_time + processes[i].burst_time;
        current_time = processes[i].finish_time;
    }

    calculate_metrics(processes, n, result);
}
