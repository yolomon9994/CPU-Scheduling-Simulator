#ifndef FCFS_H
#define FCFS_H

#include "process.h"
#include "metrics.h"

void fcfs_scheduler(Process processes[], int n, SchedulingResult *result);

#endif
