#include "rr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void rr_scheduler(Process processes[], int n, int quantum, SchedulingResult *result) {
    int *remaining_time = malloc(n * sizeof(int));
    int current_time = 0;
    int completed_processes = 0;
    
    for (int i = 0; i < n; i++) {
        remaining_time[i] = processes[i].burst_time;
        processes[i].start_time = -1;
        processes[i].finish_time = -1;
    }
    
    while (completed_processes < n) {
        bool cpu_active_in_round = false;
        
        for (int i = 0; i < n; i++) {
            if (processes[i].arrival_time <= current_time && remaining_time[i] > 0) {
                cpu_active_in_round = true;
                
                if (processes[i].start_time == -1) {
                    processes[i].start_time = current_time;
                }
                
                int time_slice = (remaining_time[i] > quantum) ? quantum : remaining_time[i];
                
                current_time += time_slice;
                remaining_time[i] -= time_slice;
                
                if (remaining_time[i] == 0) {
                    processes[i].finish_time = current_time;
                    completed_processes++;
                }
            }
        }
        
        if (!cpu_active_in_round) {
            current_time++;
        }
    }
    
    free(remaining_time);
    calculate_metrics(processes, n, result);
}
