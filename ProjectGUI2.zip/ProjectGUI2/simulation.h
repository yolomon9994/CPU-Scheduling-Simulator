#ifndef SIMULATION_H
#define SIMULATION_H

#include "process.h"
#include "fcfs.h"
#include "sjf.h"
#include "rr.h"

void run_all_algorithms(Process processes[], int count, int quantum, SchedulingResult results[3]);

void run_two_algorithms(Process processes[], int count, int quantum, 
                        const char* algo1_name, const char* algo2_name, 
                        SchedulingResult results[2]);

#endif
