#include "metrics.h"
#include <stdio.h>
#include <string.h>
#include <limits.h>

void calculate_metrics(Process processes[], int n, SchedulingResult *result) {
    int total_waiting_time = 0;
    int total_turnaround_time = 0;
    int total_burst_time = 0;
    int max_finish_time = 0;

    for (int i = 0; i < n; i++) {
        int waiting = processes[i].start_time - processes[i].arrival_time;
        if (waiting < 0) waiting = 0;

        int turnaround = processes[i].finish_time - processes[i].arrival_time;
        
        total_waiting_time += waiting;
        total_turnaround_time += turnaround;
        total_burst_time += processes[i].burst_time;
        
        if (processes[i].finish_time > max_finish_time) {
            max_finish_time = processes[i].finish_time;
        }
    }
    
    result->avg_waiting_time = (n > 0) ? (float)total_waiting_time / n : 0;
    result->avg_turnaround_time = (n > 0) ? (float)total_turnaround_time / n : 0;
    
    result->cpu_utilization = (max_finish_time > 0) ? ((float)total_burst_time / max_finish_time) * 100 : 0;
}

